﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BusBookingProject
{
    public partial class SeatDetails : System.Web.UI.Page
    {
        #region Global Variable
        SqlConnection connString = new SqlConnection(ConfigurationManager.ConnectionStrings["BusBooking"].ToString());
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    // Check for null or missing query string parameters
                    if (Request.QueryString["Origin"] != null && Request.QueryString["Destination"] != null &&
                        Request.QueryString["TravelDate"] != null && Request.QueryString["Row"] != null &&
                        Request.QueryString["Column"] != null && Request.QueryString["Fare"] != null)
                    {
                        lblForm.Text = Convert.ToString(Request.QueryString["Origin"]);
                        lblTo.Text = Convert.ToString(Request.QueryString["Destination"]);

                        // Parse the travel date
                        DateTime dtNew;
                        if (DateTime.TryParseExact(Convert.ToString(Request.QueryString["TravelDate"]), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out dtNew))
                        {
                            lbldate.Text = String.Format("{0:ddd, d MMM, yyyy}", dtNew);
                        }
                        else
                        {
                            // Handle invalid date format
                            lbldate.Text = "Invalid Date";
                        }

                        // Bind boarding points
                        BindBoardingPoints();

                        // Get booked seats
                        string bookedSeatNo = "";
                        DataTable dt = GetBookedSeat();
                        foreach (DataRow dr in dt.Rows)
                        {
                            bookedSeatNo += Convert.ToString(dr["SeatNo"]) + ",";
                        }

                        // Register startup script for seat layout
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "paramFN1",
                            "getSeatLayout('" + Convert.ToInt32(Request.QueryString["Row"]) + "','" + Convert.ToInt32(Request.QueryString["Column"]) + "','" + bookedSeatNo + "','" + Convert.ToDecimal(Request.QueryString["Fare"]) + "');", true);
                    }
                    else
                    {
                        // Handle the case where required query string parameters are missing
                        lblForm.Text = "Invalid Request";
                        lblTo.Text = "";
                        lbldate.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception and show a user-friendly error message
                // LogException(ex); // Implement a logging mechanism as required
                lblForm.Text = "An error occurred while processing your request.";
            }
        }

        private void BindBoardingPoints()
        {
            try
            {
                DataTable dsGetData = new DataTable();
                SqlCommand sqlCmd = new SqlCommand();

                if (connString.State == ConnectionState.Closed)
                {
                    connString.Open();
                }

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@BusID", Convert.ToInt32(Request.QueryString["BusID"]));
                sqlCmd.CommandText = "ispGetBoardingPoints";
                sqlCmd.Connection = connString;

                SqlDataAdapter sda = new SqlDataAdapter(sqlCmd);
                sda.Fill(dsGetData);

                if (dsGetData.Rows.Count > 0)
                {
                    dsGetData.Columns.Add(new DataColumn("Value", typeof(string), "PlaceName + ' - ' + PlaceTime"));
                    ddlBoardingpoints.DataSource = dsGetData;
                    ddlBoardingpoints.DataTextField = "Value";
                    ddlBoardingpoints.DataValueField = "StandId";
                    ddlBoardingpoints.DataBind();
                }

                ddlBoardingpoints.Items.Insert(0, new ListItem("Select Boarding Points", "0"));
            }
            catch (Exception ex)
            {
                // Log the exception and show a user-friendly error message
                // LogException(ex);
                ddlBoardingpoints.Items.Clear();
                ddlBoardingpoints.Items.Insert(0, new ListItem("Error loading boarding points", "0"));
            }
            finally
            {
                if (connString.State == ConnectionState.Open)
                {
                    connString.Close();
                }
            }
        }

        private DataTable GetBookedSeat()
        {
            DataTable dt = new DataTable();
            try
            {
                SqlCommand sqlCmd = new SqlCommand();

                if (connString.State == ConnectionState.Closed)
                {
                    connString.Open();
                }

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@BusID", Convert.ToInt32(Request.QueryString["BusID"]));
                sqlCmd.Parameters.AddWithValue("@TravelDate", Convert.ToString(Request.QueryString["TravelDate"]));
                sqlCmd.CommandText = "ispGetBookedSeatNo";
                sqlCmd.Connection = connString;

                SqlDataAdapter sda = new SqlDataAdapter(sqlCmd);
                sda.Fill(dt);
            }
            catch (Exception ex)
            {
                // Log the exception
                // LogException(ex);
            }
            finally
            {
                if (connString.State == ConnectionState.Open)
                {
                    connString.Close();
                }
            }

            return dt;
        }

        protected void btnPayment_Click(object sender, EventArgs e)
        {
            try
            {
                lblSelectedSeat.Text = Request.Form[hdnSeatNo.UniqueID];
                lblPerSeat.Text = Request.Form[hdnFare.UniqueID];

                string redirectUrl = "PassengerDetailsInfo.aspx?BusID=" + Request.QueryString["BusID"] +
                                     "&SeatNo=" + lblSelectedSeat.Text +
                                     "&TravelDate=" + Request.QueryString["TravelDate"] +
                                     "&Origin=" + Request.QueryString["Origin"] +
                                     "&Destination=" + Request.QueryString["Destination"] +
                                     "&BoardingID=" + ddlBoardingpoints.SelectedValue +
                                     "&Fare=" + lblPerSeat.Text;

                if (Session["UserID"] != null)
                {
                    Response.Redirect(redirectUrl);
                }
                else
                {
                    Response.Redirect("Login.aspx?" + redirectUrl);
                }
            }
            catch (Exception ex)
            {
                // Log the exception
                // LogException(ex);
                lblSelectedSeat.Text = "Error during payment processing.";
            }
        }
    }
}
